#!/bin/sh

./run_linux_mac.sh --lint
